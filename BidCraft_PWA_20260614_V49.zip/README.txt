BidCraft — PWA package
======================

WHAT'S IN HERE
  index.html            The full BidCraft app (works on its own, even from a USB stick)
  manifest.webmanifest  App metadata for installation
  sw.js                 Service worker — caches the app for offline use
  icon-192.png          App icon (taskbar / home screen)
  icon-512.png          App icon (large / splash)

TWO WAYS TO USE IT
------------------
1) SINGLE FILE (no setup)
   Just open index.html in Chrome, Edge, Safari or Firefox.
   Everything works; you only miss the "Install app" button.

2) INSTALLABLE APP (PWA)
   Browsers only allow installation from a web address (https or localhost),
   so put this folder somewhere served over HTTP:

   a) GitHub Pages (free, easiest to share)
      - Create a repository, upload these 5 files
      - Settings -> Pages -> deploy from branch -> root
      - Open the published URL in Chrome/Edge -> click the install icon
        in the address bar ("Install BidCraft")

   b) Your own machine / studio LAN
      - In this folder run:  python -m http.server 8080
      - Open http://localhost:8080 and install from the address bar
      - Colleagues on the LAN can open http://YOUR-IP:8080
        (note: "install" requires https or localhost, but the app itself
         runs fine over plain http on a LAN)

   c) Any static host (Netlify, Cloudflare Pages, studio intranet, ...)
      Upload the folder as-is. No build step, no server code.

AFTER INSTALLING
   - BidCraft opens in its own window with its own taskbar/dock icon
   - It works fully offline (the service worker caches everything,
     including the PDF import engine after first use)
   - Each browser profile keeps its own projects (localStorage);
     use Save Project / Load Project files to move data between machines

PRIVACY
   Nothing is ever uploaded. Scripts, tags and bids stay on the machine.
